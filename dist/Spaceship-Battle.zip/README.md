# Spaceship-pygame

## A Spaceship battle game created using python and pygame library.
### The objective is to defeat the other player by shooting at him, each player has 10 life points.

### Left players keys:

A - left,
S - down,
W - up,
D - right,
LCTRL - shoot

### Right player keys:

Left key - left,
Right key - down,
Up key - up,
Down key - right,
RCTRL - shoot
